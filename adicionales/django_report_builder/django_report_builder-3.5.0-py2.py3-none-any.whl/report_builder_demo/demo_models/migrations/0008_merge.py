# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('demo_models', '0006_account'),
        ('demo_models', '0007_auto_20150712_1752'),
    ]

    operations = [
    ]
