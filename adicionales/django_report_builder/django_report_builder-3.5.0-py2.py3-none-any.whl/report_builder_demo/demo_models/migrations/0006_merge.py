# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('demo_models', '0004_bar_date_field'),
        ('demo_models', '0005_auto_20150622_1840'),
    ]

    operations = [
    ]
